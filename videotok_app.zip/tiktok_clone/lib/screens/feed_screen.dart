import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../services/ad_service.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  // Demo videos — replace with your backend (Firebase/Supabase) later.
  final List<String> _videoUrls = const [
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
  ];

  BannerAd? _banner;
  final Map<int, VideoPlayerController> _controllers = {};

  @override
  void initState() {
    super.initState();
    _banner = AdService.instance.createBanner();
    _initController(0);
    _initController(1);
  }

  void _initController(int i) {
    if (i < 0 || i >= _videoUrls.length || _controllers.containsKey(i)) return;
    final c = VideoPlayerController.networkUrl(Uri.parse(_videoUrls[i]))
      ..setLooping(true)
      ..initialize().then((_) {
        if (mounted) setState(() {});
        if (i == 0) c.play();
      });
    _controllers[i] = c;
  }

  @override
  void dispose() {
    _banner?.dispose();
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          PageView.builder(
            scrollDirection: Axis.vertical,
            itemCount: _videoUrls.length,
            onPageChanged: (i) {
              _controllers.forEach((key, c) => c.pause());
              _initController(i - 1);
              _initController(i + 1);
              _controllers[i]?.play();
              AdService.instance.maybeShowInterstitial(); // ad every 5 videos
            },
            itemBuilder: (context, i) {
              final c = _controllers[i];
              return c != null && c.value.isInitialized
                  ? Center(child: AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)))
                  : const Center(child: CircularProgressIndicator(color: Colors.white));
            },
          ),
          // Side action bar (like/comment/share)
          Positioned(
            right: 12, bottom: 100,
            child: Column(
              children: [
                _action(Icons.favorite, '1.2k'),
                const SizedBox(height: 20),
                _action(Icons.comment, '340'),
                const SizedBox(height: 20),
                _action(Icons.share, '98'),
              ],
            ),
          ),
          // Banner ad at bottom
          if (_banner != null)
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: SizedBox(
                height: _banner!.size.height.toDouble(),
                width: _banner!.size.width.toDouble(),
                child: AdWidget(ad: _banner!),
              ),
            ),
        ],
      ),
    );
  }

  Widget _action(IconData icon, String count) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 34),
        Text(count, style: const TextStyle(color: Colors.white, fontSize: 12)),
      ],
    );
  }
}
