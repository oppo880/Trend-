# VideoTok — TikTok-স্টাইল অ্যাপ (Flutter + AdMob)

## 📱 শুধু Android ফোন দিয়ে বানানোর গাইড (ল্যাপটপ ছাড়া)

### ধাপ ১ — GitHub অ্যাকাউন্ট (ফোনের ব্রাউজারে)
1. https://github.com এ যান → Sign up করুন
2. New repository → নাম দিন `videotok` → Create

### ধাপ ২ — এই প্রজেক্টের ফাইলগুলো GitHub-এ আপলোড
1. রিপোতে "uploading an existing file" লিংকে যান
2. এই ফোল্ডারের সব ফাইল/ফোল্ডার (lib/, .github/ সহ) আপলোড করুন
   - ফোন থেকে আপলোডের সহজ উপায়: Play Store থেকে **"Acode"** (code editor) ইনস্টল করুন — সেখানে GitHub-এ কানেক্ট করে ফাইল পুশ করা যায়

### ধাপ ৩ — Cloud-এ APK বানান (ফ্রি, ল্যাপটপ লাগবে না!)
1. রিপোতে **Actions** ট্যাবে যান → "Build APK" workflow চালু করুন (Run workflow)
2. ১০-১৫ মিনিট অপেক্ষা → শেষ হলে **Artifacts** সেকশন থেকে `videotok-apk` ডাউনলোড করুন
3. APK ইনস্টল করুন → অ্যাপ চলছে! 🎉

### ধাপ ৪ — কোড এডিট করুন (Acode অ্যাপ দিয়ে)
- Acode দিয়ে lib/ ফাইল এডিট → GitHub-এ push → Actions নিজে নতুন APK বানাবে

### ধাপ ৫ — নিজের AdMob ID বসান
1. https://admob.google.com → অ্যাকাউন্ট খুলুন → অ্যাপ রেজিস্টার করুন
2. Banner/Interstitial/Rewarded Ad Unit বানান
3. `lib/services/ad_service.dart` ফাইলে test ID-র জায়গায় আপনার ID বসান

### ধাপ ৬ — Backend (Firebase, সব ফোন-ব্রাউজারে হয়)
- https://firebase.google.com → Console → নতুন প্রজেক্ট → Android অ্যাপ রেজিস্টার (SHA-1 fingerprint: Play Store থেকে "Certificate SHA-1" পাবেন)
- ভিডিও আপলোড: Firebase Storage
- লাইক/কমেন্ট/ইউজার: Cloud Firestore
- লগইন: Firebase Auth (Google/Phone)
- লাইভ স্ট্রিম: Agora (ফ্রি টিয়ার: ১০,০০০ মিনিট/মাস)

### ধাপ ৭ — Play Store-এ পাবলিশ
- https://play.google.com/console → $25 একবারের রেজিস্ট্রেশন ফি (ডেবিট/ক্রেডিট কার্ড লাগবে)
- App bundle (AAB) বানাতে workflow-এ `flutter build appbundle --release` ব্যবহার করুন
- ⚠️ নিজের অ্যাডে ক্লিক করবেন না — AdMob ব্যান করে দেবে!

## যা যা আছে এই প্রজেক্টে
- TikTok-স্টাইল vertical video feed (auto-play, loop)
- ভিডিও আপলোড স্ক্রিন (গ্যালারি থেকে)
- AdMob: Banner + Interstitial (৫ ভিডিও পরপর) + Rewarded (কয়েন অর্জন)
- ওয়ালেট স্ক্রিন

## সমস্যা হলে
- Actions-এ লাল ❌ এলে লগ দেখুন — সেখানে কী ভুল হয়েছে লেখা থাকে
- APK ইনস্টলে ব্লক করলে: Settings → Security → "Unknown sources" অন করুন
